<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,種類,純種,毛孩">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>貓咪品種</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
.na{
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  margin-right: 1rem;
  font-size: 1.25rem;
  white-space: nowrap;
  font-weight: 800;
}
.demo{
    line-height:2;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="na" color="black">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php"><font color="black">About Us<br>關於我們</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php"><font color="black">Home<br>首頁</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php"><font color="black">Pet Hospital<br>寵物醫院</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php"><font color="black">Usual Disease<br>常見疾病</font></a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </from>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <div style="background-image: url('assets/img/header.png');height:100px;opacity:0.6;"></div>
        <div style="height:100px;"></div>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
            <center><table>
                <tr>
                <?php
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM ccats WHERE num='$id'";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    echo "<tr>";
                    echo "<td rowspan='5'><img src='".$row['pic']."' width=90%></td>";
                    echo "<td colspan='3'><font face='微軟正黑體'><b>品種：</b>&nbsp;&nbsp;".$row['e_name']."&nbsp;&nbsp;&nbsp;".$row['c_name']."</font></td>";
                    echo "</tr><tr><td height='50px'></td></tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛皮種類：</b></font><font face='微軟正黑體' size='3px'>".$row['fur']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>體型：</b></font><font face='微軟正黑體' size='3px'>".$row['size']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>平均壽命：</b></font><font face='微軟正黑體' size='3px'>".$row['age']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>個性：</b></font><font face='微軟正黑體' size='3px'>".$row['personality']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>天生疾病：</b></font><font face='微軟正黑體' size='3px'>".$row['disease']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛色：</b></font><font face='微軟正黑體' size='3px'>".$row['color']."</font></td>";
                    echo "</tr>";
                ?>
            </table>
            <br><hr style="width:100%;"><br>
            <table class="demo">
                <tr>
                    <td><font face='微軟正黑體'><b>性格：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    同時擁有美國短毛貓的隨和天性，以及緬因貓的好奇和友愛性格。它們很喜歡人們的陪伴，對陌生人也會比較友好。緬因貓很黏人，喜歡玩耍，它們喜歡整個家庭，也能和小孩子很好相處。它們如果獨處較長時間會變得沮喪。
                    個性溫馴柔和，穩重好靜，然而它不怕生，感情豐富，很喜歡和人親熱，被人摟抱時喉嚨會不停的發出滿足的呼嚕聲。所以這種漂亮的黑色小貓深受人們喜愛，是人類的好伙伴。孟買貓非常好交際，易于和周圍環境融為一體，它還能孩子和狗狗友好相處，但和其它的貓不一定能相安無事。孟買貓有愛心，特別溫柔，愛依偎在主人身邊，盡管它對感情是有所客製的。孟買貓喜歡與人作伴，所以不應長時間地冷落它。
                    另外，孟買貓聰明伶俐，反應靈敏，叫聲輕柔，有時略有些頑皮。孟買貓是運動型的貓，其性格貪玩，好奇，然而有自控力，捕獵能力很強。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                    <td width='1000px'><font face='微軟正黑體'><b>需如何照顧：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    孟買貓的毛短而細很少脫落，每週梳理一次即可。在身上脫落的毛可以用麂皮輕抹就可以收集起來，讓他們的毛皮擁有絲般的光澤。洗澡不是必須的，但每年可以進行幾次。
和所有的貓一樣，修剪指甲，清潔耳朵，定期用獸醫認可的寵物牙膏刷牙，並提供一個漂亮的高抓桿來幫助它們自然的抓撓本能。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>詳細特徵：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
1） 頭：為圓形，鼻子短,下額頰發育良好。<br>

2） 耳：大小適中,尖稍呈圓弧形。<br>

3） 眼睛：呈圓形，為閃亮的古銅色，雙眼間距較寬。<br>

4） 身材：身材適中，肌肉發達。<br>

5） 四肢：粗壯，強健有力，與身體和尾相協調。<br>

6） 腳趾：趾圓形，緊湊有力，足掌黑色。腳爪小,為橢圓形<br>

7） 尾巴：長度適中。<br>
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>歷史小故事：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    孟買貓是現代品種的喵星人，1958年美國肯塔基州，路易維爾市的一位繁育家Nikki。她將一直黑貂色的緬因貓和一隻古銅色眼睛的美國短毛貓雜交，得到了一隻迷你型黑貓.黑貂色，而它的外形像極了印度的黑豹，故以印度的城市孟買命名。它是一種充滿性魅力的貓，體型如同緬因貓的外表，1980年初幾位英國繁育人開始著手培育出英國孟買貓，他們用一隻藍色緬因貓和一隻未註冊過的血統貓雜交生出了英國孟買貓，它們可能是最近黑色的緬因貓，在1976年獲得愛貓者協會的承認。
                    <font></td>
                </tr>
            </table>
            </center>
            </div>
            <?php 
    $i1=$id-1;
    $sql = "SELECT * FROM ccats WHERE num='$i1'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(!empty($row)){
        $name = $row['c_name'];
    }
?>
<style>
.test{position:relative;}
.test:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name;?>';
}
</style>
<?php 
    $i2=$id+1;
    $sql1 = "SELECT * FROM ccats WHERE num='$i2'";
    $result1 = mysqli_query($link, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    if(!empty($row1)){
        $name1 = $row1['c_name'];
    }
?>
<style>
.test1{position:relative;}
.test1:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name1;?>';
}
</style>
            <table>
                <tr>
                    <td width="50px"></td>
                    <?php $i1 = $id-1;
                        if(!empty($row)){
                        echo "<td align='left' class='test'><a href='cat_introduction$i1.php?id=$i1'><img src='assets/img/arrow-left.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="900px"></td>
                    <?php $i2 = $id+1;
                        if(!empty($row1)){
                            echo "<td align='right' class='test1'><a href='cat_introduction$i2.php?id=$i2'><img src='assets/img/arrow-right.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="50px"></td>
                </tr>
            </table>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>