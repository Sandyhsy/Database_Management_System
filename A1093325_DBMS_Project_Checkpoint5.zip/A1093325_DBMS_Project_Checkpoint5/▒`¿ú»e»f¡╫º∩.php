<?php
session_start();
$name=$_SESSION['name'];
$_SESSION['name']=$name;
$userID = $_GET['id'];

$conn=require_once "database.php";

$sql = "SELECT * FROM disease WHERE dname='$userID'";
$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);
if(mysqli_num_rows($result)){
    $dname = $row['dname'];
    $dcause = $row['dcause'];
    $dprevent = $row['dprevent'];
}
if (isset($_POST["action"]) && $_POST["action"] == 'update') {

    $newdname = $_POST['dname'];
    $newdcause = $_POST['dcause'];
    $newdprevent = $_POST['dprevent'];
    $sql_query = "UPDATE disease SET dname='$newdname', dcause='$newdcause', dprevent='$newdprevent' WHERE dname='$userID'";
    // echo "<script>alert('更新成功!')</script>";
    mysqli_query($link,$sql_query);
    $link->close();
    header('Location: 常見疾病.php');
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="cats" />
        <meta name="author" content="" />
        <title>常見疾病修改</title>
        <link rel="icon" href="assets/img/catlogo.png" width="30%">
        <link rel=stylesheet type="text/css" href="css\all.css">
<style>
body{
    margin:0;
    padding:0;
}
.header{
    background-color: #7d93a8; 
    height:120px;
}
.color{
    color:black;
    border-color:#708090;
    width:280px;
    height:60px;
    background-color:#7d93a8;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.divblock{
	width:1200px;
	height:auto;
	margin:20px auto; 
}
.block{
    width:500px;
	height:100px;
    /* word-wrap : break-word; */
    /* text-wrap:'unrestricted'; */
    /* display: inline-block; */
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
</style>
    </head>
    <header class="header">
        <form action="search.php" method="POST"><table>
            <tr>
                <td width='25'></td>
                <td><br><img src="assets/img/catlogo.png" width=80 height=80 /></td>
                <td width='15'></td>
                <td><font face="Gungsuh" color=white><h2>CAT LOVERS</h2></font></td>
                <td width='325'></td>
                <td valign="bottom">
                    <input class="input" type="button" value="貓咪品種" onclick="location.href='貓咪品種.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="寵物醫院" onclick="location.href='寵物醫院.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="常見疾病" onclick="location.href='常見疾病.php'"></td>
                <td valign="bottom">
                    <div class="search-criteria-bar">
                        <input style="height: 34px;" itemprop="query-input" style="height:48px" type="text" name="search" id="q" value placeholder="常見疾病搜尋" required>
                        <button class="input" id="button-search" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>搜 尋
                        </button>
                    </div>
                </td>
                <td valign="top">
<?php
    echo $name;
?>
                </td>
                <td valign="top">
                    <img src="assets/img/exit.png" style="width:20px;height:20px;" onclick="location.href='index.php'">
                </td>
                <td width='25'></td>
            </tr>
        </table></form>
</header>
<body>

<div class="divblock">
    <center><font face="微軟正黑體" size="5"><b><font size="6"><?php echo $userID;?></font> 更新</b></font>
    <br><br>
    <form action="" method="post" name="formAdd" id="formAdd">
        <table style="border-top:3px #FFD382 solid;" cellpadding="10" border='0'>
            <tr>
                <td>疾病名稱：</td>
                <td style="width:500px;height:50px;"><input type="text" name="dname" id="dname" value=" <?php echo $dname ?>" required="required"><br/>
            </td></tr><tr>
                <td>介    紹：</td>
                <td style="width:500px;height:100px;"><input class="block" type="text" name="dcause" id="dcause" value="<?php echo $dcause ?>" required="required"><br/>
            </td></tr><tr>   
                <td>預防方法：</td>
                <td style="width:500px;height:100px;"><input class="block" type="text" name="dprevent" id="dprevent" value="<?php echo $dprevent ?>" required="required"><br/>
            </td></tr><tr>
                <td colspan='2' align="center"><input type="hidden" name="action" value="update">
                <input class="input" style="width:150px;height:50px;" type="submit" name="button" value="確定修改">
            </td></tr>
        </table>
    </form></center>
</div>
</body>
<footer id="footer" class="footer"><br>
    <p style="text-align: center;"><font color="white" size=2px face="微軟正黑體"><strong>CAT LOVERS</strong></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://cfa.org/">CFA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://tica.org/zh-tw/">TICA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://www.worldcatcongress.org/">WCC協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">全國動物收容</a></font></p> 
    <br>
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體">Copyright ©2022 CAT LOVERS</font></p> 
</footer>
</html>