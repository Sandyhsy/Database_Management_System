<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,種類,純種,毛孩">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>貓咪品種</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
.na{
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  margin-right: 1rem;
  font-size: 1.25rem;
  white-space: nowrap;
  font-weight: 800;
}
.demo{
    line-height:2;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="na" color="black">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php"><font color="black">About Us<br>關於我們</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php"><font color="black">Home<br>首頁</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php"><font color="black">Pet Hospital<br>寵物醫院</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php"><font color="black">Usual Disease<br>常見疾病</font></a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </from>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <div style="background-image: url('assets/img/header.png');height:100px;opacity:0.6;"></div>
        <div style="height:100px;"></div>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
            <center><table>
                <tr>
                <?php
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM ccats WHERE num='$id'";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    echo "<tr>";
                    echo "<td rowspan='5'><img src='".$row['pic']."' width=90%></td>";
                    echo "<td colspan='3'><font face='微軟正黑體'><b>品種：</b>&nbsp;&nbsp;".$row['e_name']."&nbsp;&nbsp;&nbsp;".$row['c_name']."</font></td>";
                    echo "</tr><tr><td height='50px'></td></tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛皮種類：</b></font><font face='微軟正黑體' size='3px'>".$row['fur']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>體型：</b></font><font face='微軟正黑體' size='3px'>".$row['size']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>平均壽命：</b></font><font face='微軟正黑體' size='3px'>".$row['age']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>個性：</b></font><font face='微軟正黑體' size='3px'>".$row['personality']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>天生疾病：</b></font><font face='微軟正黑體' size='3px'>".$row['disease']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛色：</b></font><font face='微軟正黑體' size='3px'>".$row['color']."</font></td>";
                    echo "</tr>";
                ?>
            </table>
            <br><hr style="width:100%;"><br>
            <table class="demo">
                <tr>
                    <td><font face='微軟正黑體'><b>性格：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    波米拉貓很需要一個家，牠們是很棒的家貓。喜歡受到關注，經常需要人家撫摸。雖然波米拉貓個性好奇又友善，但是無法立刻與陌生人接近，不過最後還是能讓訪客感到暖心。

這個天生可愛的貓咪有趣溫馨，不過也非常安靜溫順，與孩子和其他動物都能相處得很好。總而言之，波米拉貓天性既聰明又好奇，而且又情感豐富，擁有最具吸引力的特質。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                    <td width='1000px'><font face='微軟正黑體'><b>需如何照顧：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    在美容方面，大多數波米拉貓的美容清潔成本很低。 建議每週刷牙或梳理一次。
與所有貓一樣，要定期修剪指甲、清潔耳朵和刷牙，並使用獸醫認可的寵物牙膏，並提供一個漂亮的高抓桿來幫助它們自然的抓撓本能。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>詳細特徵：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
1） 頭：楔形短頭。<br>

2） 耳：間距中等。<br>

3） 眼睛：大而有表現力；眼間距寬並且稍稍傾斜的眼位。有弧度的上眼瞼向鼻子傾斜呈角度，下眼瞼的弧度更加完整一些。眼睛的顏色清楚明亮，輪廓的顏色是基本色。<br>

4） 身材：中等身材，姿態優雅但渾身都是肌肉。<br>

5） 四肢：與身體成比例，後肢比前肢稍長。<br>

6） 腳趾：圓形，中等大小的爪。小而呈橢圓形。<br>

7） 尾巴：中至長的尾巴基部粗細中等；尖端變細到呈圓形的尾尖。<br>
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>歷史小故事：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    銀色金吉拉長毛貓和淡紫色緬甸貓無意間交配產下的小貓便是最初的波米拉貓種貓。米蘭達·馮·克奇伯格男爵夫人建立一個培育計劃，意欲培育出有緬甸貓外形和銀色金吉拉毛尖色的小貓。波米拉貓於1983年在貓協會舉辦的展示會上首次登台參展。查爾斯和特瑞慈·克拉克夫婦培育出另一種血統波米拉貓則斑紋優美，將這兩個品種結合，培育出了品質更佳的後裔。

波米拉貓集合了金吉拉的美和緬甸貓的貼心。這可是有段美好的貓貓愛情故事，話說很久以前，有一位金吉拉公主在被送去見一位金吉拉王子，共創美好家庭的前夕，金吉拉公主逃出粗心的傭人手心，一不小心進入了她不該進去的禁地——書房，在書房中住著一位英俊的緬甸貓王子，金吉拉公主和緬甸貓王子就在月黑風高之時偷嘗了禁果，而生下了超可愛的波米拉貓。
                    <font></td>
                </tr>
            </table>
            </center>
            </div>
            <?php 
    $i1=$id-1;
    $sql = "SELECT * FROM ccats WHERE num='$i1'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(!empty($row)){
        $name = $row['c_name'];
    }
?>
<style>
.test{position:relative;}
.test:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name;?>';
}
</style>
<?php 
    $i2=$id+1;
    $sql1 = "SELECT * FROM ccats WHERE num='$i2'";
    $result1 = mysqli_query($link, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    if(!empty($row1)){
        $name1 = $row1['c_name'];
    }
?>
<style>
.test1{position:relative;}
.test1:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name1;?>';
}
</style>
            <table>
                <tr>
                    <td width="50px"></td>
                    <?php $i1 = $id-1;
                        if(!empty($row)){
                        echo "<td align='left' class='test'><a href='cat_introduction$i1.php?id=$i1'><img src='assets/img/arrow-left.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="900px"></td>
                    <?php $i2 = $id+1;
                        if(!empty($row1)){
                            echo "<td align='right' class='test1'><a href='cat_introduction$i2.php?id=$i2'><img src='assets/img/arrow-right.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="50px"></td>
                </tr>
            </table>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>