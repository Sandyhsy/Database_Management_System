<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,種類,純種,毛孩">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>貓咪品種</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
.na{
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  margin-right: 1rem;
  font-size: 1.25rem;
  white-space: nowrap;
  font-weight: 800;
}
.demo{
    line-height:2;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="na" color="black">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php"><font color="black">About Us<br>關於我們</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php"><font color="black">Home<br>首頁</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php"><font color="black">Pet Hospital<br>寵物醫院</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php"><font color="black">Usual Disease<br>常見疾病</font></a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </from>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <div style="background-image: url('assets/img/header.png');height:100px;opacity:0.6;"></div>
        <div style="height:100px;"></div>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
            <center><table>
                <tr>
                <?php
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM ccats WHERE num='$id'";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    echo "<tr>";
                    echo "<td rowspan='5'><img src='".$row['pic']."' width=90%></td>";
                    echo "<td colspan='3'><font face='微軟正黑體'><b>品種：</b>&nbsp;&nbsp;".$row['e_name']."&nbsp;&nbsp;&nbsp;".$row['c_name']."</font></td>";
                    echo "</tr><tr><td height='50px'></td></tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛皮種類：</b></font><font face='微軟正黑體' size='3px'>".$row['fur']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>體型：</b></font><font face='微軟正黑體' size='3px'>".$row['size']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>平均壽命：</b></font><font face='微軟正黑體' size='3px'>".$row['age']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>個性：</b></font><font face='微軟正黑體' size='3px'>".$row['personality']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>天生疾病：</b></font><font face='微軟正黑體' size='3px'>".$row['disease']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛色：</b></font><font face='微軟正黑體' size='3px'>".$row['color']."</font></td>";
                    echo "</tr>";
                ?>
            </table>
            <br><hr style="width:100%;"><br>
            <table class="demo">
                <tr>
                    <td><font face='微軟正黑體'><b>性格：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    德文捲毛貓還有個外號叫捲毛狗，這是因為它們像小狗一樣喜歡搖尾巴，很頑皮、像淘氣的小精靈。它自懂得四腳站立開始，就喜
                    歡親近人類，它是各個品種中最喜歡與人類接觸及交朋友的品種之一。也保留著喵星人驕傲的情懷，獨立思考時，就好像一隻小精
                    靈在想要用什麼方法給人類搗亂。它活潑近人的性格與及其易於打理的皮毛，絕對是一隻理想的家庭貓。它們看起來瘦瘦小小，實
                    際上非常健壯。它們總是閒不住，無論有沒有人陪，自娛自樂的樂觀精神從來都不讓人擔心。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                    <td width='1000px'><font face='微軟正黑體'><b>需如何照顧：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    德文捲毛貓是屬於比較挑食的貓咪，所以主人在選擇貓糧時要了解貓咪喜歡哪種口味。天性活潑好動，需要足夠的運動量來消耗能
                    量和鍛煉身體，主人一定要陪著貓咪一起運動。另一特點是易於打理，洗澡後只要用毛巾輕抹或曬曬太陽即可。它的脫毛情況相當
                    輕微，甚至不容易被發覺，適合一些對貓毛敏感的朋友。但主人也應該隨時保證德文捲毛貓的毛髮乾淨，一個乾淨的身體，才會給
                    貓咪帶來好的心情和健康的身體。但也不要過於頻繁的洗澡。因為他們體表會分泌一種保護皮膚的油脂，過於頻繁的洗澡容易破壞
                    這層天然的油脂層，反而會傷害他們的皮膚。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>詳細特徵：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
1） 頭：它的頭部呈楔形，有一張“小精靈”樣的臉蛋，顴骨寬，頭部相對較小，有著短鼻口，捲曲的鬍鬚。<br>

2） 耳：他們有一對很大而且尖尖的耳朵，耳底部和間距都很寬。<br>

3） 眼睛：眼睛也很大，呈橢圓形，擁有各種顏色。<br>

4） 身材：身材苗條，纖細，肌肉結實，胸寬，腰高。<br>

5） 四肢：四肢細長，足掌呈橢圓形。<br>

6） 腳趾：腳爪小，有粉紅色的腳趾。<br>

7） 尾巴：有一隻錐形長尾上密蓋著毛的尾巴。<br>
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>歷史小故事：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    1960年，在英國德文郡又發現了一隻捲毛貓，它是繼1950年在英國柯尼斯郡發現的柯尼斯貓後的又一捲毛貓。

德文貓的母親是一隻玳瑁顏色的貓，父親是一隻有著捲曲被毛的流浪貓。在同胞兄妹中，只有它有著一身捲曲的被毛，也就是它，後來被用作第一隻繁育該品種的種貓。

起初，人們以為德文貓和柯尼斯貓有血緣關係，但是用它們交配生的都是直毛貓，這就證明德文貓和柯尼斯貓是兩種不同基因形成的。在地域如此接近的情況下，出現了兩種不同的隱性基因，並造成了兩種略有不同的捲曲被毛的貓。
                    <font></td>
                </tr>
            </table>
            </center>
            </div>
            <?php 
    $i1=$id-1;
    $sql = "SELECT * FROM ccats WHERE num='$i1'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(!empty($row)){
        $name = $row['c_name'];
    }
?>
<style>
.test{position:relative;}
.test:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name;?>';
}
</style>
<?php 
    $i2=$id+1;
    $sql1 = "SELECT * FROM ccats WHERE num='$i2'";
    $result1 = mysqli_query($link, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    if(!empty($row1)){
        $name1 = $row1['c_name'];
    }
?>
<style>
.test1{position:relative;}
.test1:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name1;?>';
}
</style>
            <table>
                <tr>
                    <td width="50px"></td>
                    <?php $i1 = $id-1;
                        if(!empty($row)){
                        echo "<td align='left' class='test'><a href='cat_introduction$i1.php?id=$i1'><img src='assets/img/arrow-left.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="900px"></td>
                    <?php $i2 = $id+1;
                        if(!empty($row1)){
                            echo "<td align='right' class='test1'><a href='cat_introduction$i2.php?id=$i2'><img src='assets/img/arrow-right.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="50px"></td>
                </tr>
            </table>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>