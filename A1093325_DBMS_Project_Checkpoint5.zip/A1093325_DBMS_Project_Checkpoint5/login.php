 <?php
session_start();

$conn=require_once "database.php";
$name=$_POST["name"];
$pwd=$_POST["pwd"];


 $pwd_hash=password_hash($pwd,PASSWORD_DEFAULT);

 if($_SERVER["REQUEST_METHOD"] == "POST"){
     $sql = "SELECT * FROM uuser WHERE name ='$name' AND pwd ='$pwd'";
     $result=mysqli_query($conn,$sql);
     $row=mysqli_fetch_assoc($result);
     if(mysqli_num_rows($result) >0){
        if($pwd ==$row["pwd"]){
            $_SESSION["num"] = mysqli_fetch_assoc($result)["num"];
            // $_SESSION["name"] = mysqli_fetch_assoc($result)["name"];
            $_SESSION['name']=$row['name'];
            echo $_SESSION['name'];
            header("location:b_cat.php");
        }else{
            function_alert("帳號或密碼錯誤"); 
        }
    }
 }
     else{
         function_alert("有東西出錯了"); 
     }

     mysqli_close($link);
 
 function function_alert($message) { 

     echo "<script>alert('$message');
     window.location.href='loginpage.php';
     </script>"; 
     return false;
 } 

?> 