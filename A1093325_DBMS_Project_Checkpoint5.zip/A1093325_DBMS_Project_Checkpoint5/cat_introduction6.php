<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,種類,純種,毛孩">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>貓咪品種</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
.na{
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  margin-right: 1rem;
  font-size: 1.25rem;
  white-space: nowrap;
  font-weight: 800;
}
.demo{
    line-height:2;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="na" color="black">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php"><font color="black">About Us<br>關於我們</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php"><font color="black">Home<br>首頁</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php"><font color="black">Pet Hospital<br>寵物醫院</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php"><font color="black">Usual Disease<br>常見疾病</font></a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </from>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <div style="background-image: url('assets/img/header.png');height:100px;opacity:0.6;"></div>
        <div style="height:100px;"></div>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
            <center><table>
                <tr>
                <?php
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM ccats WHERE num='$id'";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    echo "<tr>";
                    echo "<td rowspan='5'><img src='".$row['pic']."' width=90%></td>";
                    echo "<td colspan='3'><font face='微軟正黑體'><b>品種：</b>&nbsp;&nbsp;".$row['e_name']."&nbsp;&nbsp;&nbsp;".$row['c_name']."</font></td>";
                    echo "</tr><tr><td height='50px'></td></tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛皮種類：</b></font><font face='微軟正黑體' size='3px'>".$row['fur']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>體型：</b></font><font face='微軟正黑體' size='3px'>".$row['size']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>平均壽命：</b></font><font face='微軟正黑體' size='3px'>".$row['age']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>個性：</b></font><font face='微軟正黑體' size='3px'>".$row['personality']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>天生疾病：</b></font><font face='微軟正黑體' size='3px'>".$row['disease']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛色：</b></font><font face='微軟正黑體' size='3px'>".$row['color']."</font></td>";
                    echo "</tr>";
                ?>
            </table>
            <br><hr style="width:100%;"><br>
            <table class="demo">
                <tr>
                    <td><font face='微軟正黑體'><b>性格：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;澳大利亞霧貓這個罕見的品種天生好玩，活潑，與人相處融洽，適合做家庭寵物。

等級界定方式為性格越為溫順的評價越高，但普遍此貓種都有一顆先天愛家的心。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                    <td width='1000px'><font face='微軟正黑體'><b>需如何照顧：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;作為伴侶動物，澳大利亞迷霧貓很居家，他喜歡你為它準備一堆玩具，然後自己玩耍，很少會自己擅自跑到外面去。

因為有很高的健康度，也不用為其突發疾病而煩惱，總之，它是一種非常適合大家庭餵養的寵物。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>詳細特徵：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
1） 頭：頭部圓楔形，線條流暢。<br>

2） 耳：眼睛深金色，杏仁形，稍向上翹。<br>

3） 眼睛：耳朵中等大小，直立或稍有些偏立，耳尖圓滑。<br>

4） 身材：肌肉發達且強壯，但體格中等。<br>

5） 腳趾：圓形，中等大小的爪。小而呈橢圓形。<br>

6） 尾巴：長度適中，逐漸變細，尾端渾圓。<br>
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>歷史小故事：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;托達史托德博士在澳大利亞的新南威爾斯啟動了一個新計畫，要培育出人性化的居家寵物品種，該品種結合了緬甸貓的體格及友善和阿比西尼亞貓的細密的被毛及氣質，顯現出家貓的斑點，並推遲了發情期過早的趨勢。1980年1月第一次分娩，產下的貓有1/2緬甸貓血統、1/4阿比西尼亞貓血統和1/4家貓血統，這就是澳大利亞霧貓。
                    澳大利亞霧貓是在澳洲第一個土生土長的貓種，原本被稱為斑點霧貓，因為牠們身上會出現細微的斑點，不過這些斑點必須一年左右的時間才會發展成熟，而細緻的條紋會營造出如水霧一般的效果，微微的朦朧感使澳大利亞霧貓的毛皮更加勻稱柔和。
                </tr>
            </table>
            </center>
            </div>
            <?php 
    $i1=$id-1;
    $sql = "SELECT * FROM ccats WHERE num='$i1'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(!empty($row)){
        $name = $row['c_name'];
    }
?>
<style>
.test{position:relative;}
.test:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name;?>';
}
</style>
<?php 
    $i2=$id+1;
    $sql1 = "SELECT * FROM ccats WHERE num='$i2'";
    $result1 = mysqli_query($link, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    if(!empty($row1)){
        $name1 = $row1['c_name'];
    }
?>
<style>
.test1{position:relative;}
.test1:hover::before{
position: absolute;
top: -50px;
right: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name1;?>';
}
</style>
            <table>
                <tr>
                    <td width="50px"></td>
                    <?php $i1 = $id-1;
                        if(!empty($row)){
                        echo "<td align='left' class='test'><a href='cat_introduction$i1.php?id=$i1'><img src='assets/img/arrow-left.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="900px"></td>
                    <?php $i2 = $id+1;
                        if(!empty($row1)){
                            echo "<td align='right' class='test1'><a href='cat_introduction$i2.php?id=$i2'><img src='assets/img/arrow-right.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="50px"></td>
                </tr>
            </table>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>