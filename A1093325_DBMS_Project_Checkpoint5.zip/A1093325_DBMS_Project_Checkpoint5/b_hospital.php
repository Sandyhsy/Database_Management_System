<?php
session_start();
$name=$_SESSION['name'];
$_SESSION['name']=$name;
?>
<!DOCTYPE html>
<html lang="zh-TW">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>寵物醫院管理</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />
        <link rel=stylesheet type="text/css" href="css\all.css">

        <style>
body{
    margin:0;
    padding:0;
}
.header{
    background-color: #7d93a8; 
    height:120px;
}
.color{
    color:black;
    border-color:#708090;
    width:280px;
    height:60px;
    background-color:#7d93a8;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.divblock{
	width:1200px;
	height:auto;
	margin:20px auto; 
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
</style>
    </head>
    <header class="header">
        <form action="search_hos.php" method="POST"><table>
            <tr>
                <td width='25'></td>
                <td><br><img src="assets/img/catlogo.png" width=80 height=80 /></td>
                <td width='15'></td>
                <td><font face="Gungsuh" color=white><h2>CAT LOVERS</h2></font></td>
                <td width='325'></td>
                <td valign="bottom">
                    <input class="input" type="button" value="貓咪品種" onclick="location.href='b_cat.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="寵物醫院" onclick="location.href='b_hospital.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="常見疾病" onclick="location.href='b_disease.php'"></td>
                <td valign="bottom">
                    <div class="search-criteria-bar">
                        <input style="height: 34px;" itemprop="query-input" style="height:48px" type="text" name="search" id="q" value placeholder="寵物醫院搜尋" required>
                        <button class="input" id="button-search" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>搜 尋
                        </button>
                    </div>
                </td>
                <td valign="top">
<?php
    echo $name;
?>
                </td>
                <td valign="top">
                    <img src="assets/img/exit.png" style="width:20px;height:20px;" onclick="location.href='index.php'">
                </td>
                <td width='25'></td>
            </tr>
        </table></form>
</header>
<body>
<div class="divblock">
&nbsp;&nbsp;
<img src="assets/img/hospital.png" style="width:40px;height:40px;">
    <font style="font-style:'微軟正黑體';font-weight:bold;font-size:30px;">寵物醫院</font>
    <!-- <a href='hos_update.php'style="text-decoration:none;margin-left:800px;">新增寵物醫院<img src='assets/img/add.png' style='width:20px;height:20px;'></a> -->
    <br><br>
        <center><table>
                <tr>   
                    <td width='200'><font face='微軟正黑體' size='4px'>醫院名稱</font></td>
                    <td width='200'><font face='微軟正黑體' size='4px'>電話號碼</font></td>
                    <td width='350'><font face='微軟正黑體' size='4px'>地址</font></td>
                    <td width='150'><font face='微軟正黑體' size='4px'>備註</font></td>
                    <!-- <td width='50' align="center"><font face='微軟正黑體' size='4px'>修改</font></td> -->
                    <td width='50' align="center"><font face='微軟正黑體' size='4px'>刪除</font></td>
                </tr>
        </table></center>
    <hr width=90%>

    <center><form action="hos_revise.php" method="POST"><table>
<?php
    require 'database.php';
    $SQL="SELECT * FROM hhospital";
    $result=mysqli_query($link, $SQL);
    $count=mysqli_num_rows($result);
    for($i=1;$i<=$count;$i++){
        if($i%2!=0){
            $sql = "SELECT * FROM hhospital WHERE num='$i'";
            $result = mysqli_query($link, $sql);
            $row = mysqli_fetch_assoc($result);
            if(!empty($row)){
                $id = $row['num'];
                $SQL1 = "SELECT * FROM aarea a, hhospital h WHERE a.id = h.city AND h.num='$id'";
                $result1 = mysqli_query($link, $SQL1);
                $row1 = mysqli_fetch_assoc($result1);
                // if(!empty($row1)){
                echo "<tr bgcolor='#EAF2F8'>";
                echo "<td width='200'><font face='微軟正黑體' name='hname' id='hname'>".$row['hname']."</font></td>";
                echo "<td width='200'><font face='微軟正黑體' name='tel' id='tel'>".$row['tel']."</font></td>";
                // echo "<p name='city' id='city' hidden>".$row1['num']."</p>";
                echo "<td width='350'><font face='微軟正黑體'>".$row1['town'].$row1['district'].$row['address']."</font></td>";
                echo "<td width='150'><font face='微軟正黑體' name='special' id='special'>".$row['special']."</font></td>";
                // echo "<td width='50' align='center'><a href='hos_revise.php?id=$id'><img src='assets/img/pencil.png' style='width:20px;height:20px;'></a></td>";
                echo "<td width='50' align='center'><a href='hos_delete.php?id=$id'><img src='assets/img/delete.png' style='width:20px;height:20px;'></a></td></tr>";
                echo "<tr><td height='30'></td>";
                echo "</tr>";
            // }
            }
        }
        if($i%2==0){
            $sql = "SELECT * FROM hhospital WHERE num='$i'";
            $result = mysqli_query($link, $sql);
            $row = mysqli_fetch_assoc($result);
            if(!empty($row)){
                $id = $row['num'];
                $SQL12 = "SELECT * FROM aarea a, hhospital h WHERE a.id = h.city AND h.num='$id'";
                $result12 = mysqli_query($link, $SQL12);
                $row12 = mysqli_fetch_assoc($result12);
                // if(!empty($row12)){
                echo "<tr>";
                echo "<td width='200'><font face='微軟正黑體' name='hname' id='hname'>".$row['hname']."</font></td>";
                echo "<td width='200'><font face='微軟正黑體' namez='tel' id='tel'>".$row['tel']."</font></td>";
                // echo "<p name='city' id='city' hidden>".$row1['num']."</p>";
                echo "<td width='350'><font face='微軟正黑體'>".$row12['town'].$row12['district'].$row['address']."</font></td>";
                echo "<td width='150'><font face='微軟正黑體' name='special' id='special'>".$row['special']."</font></td>";
                // echo "<td width='50' align='center'><a href='hos_revise.php?id=$id'><img src='assets/img/pencil.png' style='width:20px;height:20px;'></a></td>";
                echo "<td width='50' align='center'><a href='hos_delete.php?id=$id'><img src='assets/img/delete.png' style='width:20px;height:20px;'></a></td></tr>";
                echo "<tr><td height='30'></td>";
                echo "</tr>";
                // }
            }
        }
    }
?>
    </table></form></center>
</div>
</body>
<button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
<footer id="footer" class="footer"><br>
    <p style="text-align: center;"><font color="white" size=2px face="微軟正黑體"><strong>CAT LOVERS</strong></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://cfa.org/">CFA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://tica.org/zh-tw/">TICA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://www.worldcatcongress.org/">WCC協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">全國動物收容</a></font></p> 
    <br>
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體">Copyright ©2022 CAT LOVERS</font></p> 
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>
