<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <title>管理者登入</title>
    <meta charset="utf-8"/>
    <meta name="description" content="catbreeds">
    <meta name="keyword" content="貓咪,品種,cat,breeds,毛小孩,飼養,照顧">
    <link rel="icon" href="assets/img/catlogo.png" width="30%">
    <link rel=stylesheet type="text/css" href="css\all.css">
<style>
body{
    margin:0;
    padding:0;
}
div{
    height:auto;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.login{
    margin-top:50px;
    margin-left:475px;
    margin-bottom:100px;
    width:500px;
    height:250px;
    opacity: 0.75;
}
::placeholder {
	color: black;
}
.color{
    color:black;
    border-color:#708090;
    width:280px;
    height:60px;
    background-color:#7d93a8;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
</style>

</head>
<header class="header">
    <table>
        <tr>
            <td width='25'></td>
            <td><br><img src="assets/img/catlogo.png" width=80 height=80 /></td>
            <td width='15'></td>
            <td><font face="Gungsuh" color=white><h2>CAT LOVERS</h2></font></td>
            <td width='325'></td>
            <td valign="bottom">
                <input class="input" type="button" value="關於我們" onclick="location.href='about.php'"></td>
            <td valign="bottom">
                <input class="input" type="button" value="首頁" onclick="location.href='index.php'"></td>
            <td valign="bottom">
                <input class="input" type="button" value="寵物醫院" onclick="location.href='hospital.php'"></td>
            <td valign="bottom">
                <input class="input" type="button" value="常見疾病" onclick="location.href='disease.php'"></td>
            <td valign="bottom" width="500px"></td>
            <td>
                <img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'">
            </td>
            <td width='25'></td>
        </tr>
    </table>
</header>

<body>
<div class="div">
<br><br>
    <form class="login" action="login.php" method="POST">
        <table style="border:3px #7d93a8 solid;padding:5px;" rules="all" cellpadding='5'>
        <tr class="color">
            <td align='center' valign="middle" style="width:300px;"><font style="font-weight:bold;" size=5px face="微軟正黑體">管理者登入</font></td>
        </tr><tr style="background-color:#c8d8df">
            <td colspan="2" align='center' valign="middle"><br>
            <font style="font-weight:bold;font-size:15px;">帳號：</font><input name="name" type="text" placeholder="  帳號" required="required">
            <br><br>
            <font style="font-weight:bold;font-size:15px;">密碼：</font><input name="pwd" type="password" placeholder="  密碼" required="required">
            <br><br>
            <!-- <a href='忘記密碼.php' class="link">忘記密碼?</a>
            <br><br> -->
            <input class="input" type="submit" name="submit" value="登 入">
            </td>
        </tr>
        </table>
    </form>
</div>
</body>
<footer id="footer" class="footer"><br>
    <p style="text-align: center;"><font color="white" size=2px face="微軟正黑體"><strong>CAT LOVERS</strong></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://cfa.org/">CFA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://tica.org/zh-tw/">TICA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://www.worldcatcongress.org/">WCC協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">全國動物收容</a></font></p> 
    <br>
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體">Copyright ©2022 CAT LOVERS</font></p> 
</footer>
</html>
