<?php
session_start();
require "database.php";
$name=$_SESSION['name'];
$_SESSION['name']=$name;

if (isset($_POST["action"]) && $_POST["action"] == 'update') {

    $shopid=$_POST['shopid'];
    $hname=$_POST["hname"];
    $tel=$_POST["tel"];
    $town=$_POST["town"];
    $district=$_POST["district"];
    $address=$_POST["address"];
    $special=$_POST["special"];

    $sql_2 = "SELECT * FROM aarea WHERE town='$town' AND district='$district'";
    $result_2=mysqli_query($link,$sql_2);
    $row_2=mysqli_fetch_assoc($result_2);

    if(!empty($row_2)){
        $newcityid = $row_2['id'];
        $SQL = "UPDATE hhospital SET city='$newcityid',hname='$hname',address='$address',tel='$tel', special='$special' WHERE  num='$shopid'";
        if(mysqli_query($link,$SQL))
        {
        echo "<script type='text/javascript'>";
        echo "alert('修改成功')";
        echo "</script>";
        echo "<meta http-equiv='Refresh' content='0; url=b_hospital.php'>";
        }else{
            echo "<script type='text/javascript'>";
            echo "alert('修改失敗')";
            echo "</script>";
        }
    }else{
        echo "<script type='text/javascript'>";
        echo "alert('修改失敗')";
        echo "</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="cats" />
    <meta name="author" content="Sandy Huang" />
    <title>寵物醫院修改</title>
    <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />
    <link rel=stylesheet type="text/css" href="css\all.css">
        
<style>
body{
    margin:0;
    padding:0;
}
.header{
    background-color: #7d93a8; 
    height:120px;
}
.color{
    color:black;
    border-color:#708090;
    width:280px;
    height:60px;
    background-color:#7d93a8;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.divblock{
	width:1200px;
	height:auto;
	margin:20px auto; 
}
.block{
    width:500px;
	height:150px;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
</style>

</head>
<header class="header">
        <table>
            <form action="search_hos.php" method="POST"><tr>
                <td width='25'></td>
                <td><br><img src="assets/img/catlogo.png" width=80 height=80 /></td>
                <td width='15'></td>
                <td><font face="Gungsuh" color=white><h2>CAT LOVERS</h2></font></td>
                <td width='325'></td>
                <td valign="bottom">
                    <input class="input" type="button" value="貓咪品種" onclick="location.href='b_cat.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="寵物醫院" onclick="location.href='b_hospital.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="常見疾病" onclick="location.href='b_disease.php'"></td>
                <td valign="bottom">
                    <div class="search-criteria-bar">
                        <input style="height: 34px;" itemprop="query-input" style="height:48px" type="text" name="search" id="q" value placeholder="寵物醫院搜尋" required>
                        <button class="input" id="button-search" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>搜 尋
                        </button>
                    </div>
                </td>
                <td valign="top">
<?php
    echo $name;
?>
                </td>
                <td valign="top">
                    <img src="assets/img/exit.png" style="width:20px;height:20px;" onclick="location.href='index.php'">
                </td>
                <td width='25'></td>
            </tr>
        </table></form>
</header>
<body>
<div class="divblock">
    <?php
    $userID = $_GET['id'];
    $sql = "SELECT * FROM hospital WHERE num='$userID'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(mysqli_num_rows($result)>0){
        $city = $row['city'];
    }
    
    $sqlcity = "SELECT * FROM area WHERE id='$city'";
    $resultcity = mysqli_query($link, $sqlcity);
    $rowcity = mysqli_fetch_assoc($resultcity);
    
    ?>
    <center><font face="微軟正黑體" size="5"><b><font size="6"><?php echo $row['hname'];?></font> 更新</b></font>
    <br><br>				
        <form action="" method="POST" name="formAdd" id="formAdd">
            <input type="hidden" name="shopid" value="<?php echo $userID;?>">
            <table style="border-top:3px #FFD382 solid;" cellpadding="10" border='0'>
				<tr>
			    	<td>醫院名稱：</td>
					<td style="width:250px;height:50px;"><input type="text" name="hname" id="hname" value=" <?php echo $row['hname']; ?>" required="required"></td>
				</tr><tr>
					<td>電話號碼：</td>
					<td style="width:250px;height:50px;"><input type="text" name="tel" id="tel" value=" <?php echo $row['tel']; ?>" required="required"></td>
				</tr><tr>
					<td>縣市：</td>
					<td style="width:250px;height:50px;"><input type="text" name="town" id="town" value=" <?php echo $rowcity['town']; ?>" required="required"></td>
				</tr><tr>
                    <td>區域：</td>
					<td style="width:250px;height:50px;"><input type="text" name="district" id="district" value=" <?php echo $rowcity['district']; ?>" required="required"></td>
				</tr><tr>
					<td>詳細地址：</td>
					<td style="width:250px;height:50px;"><input type="text" name="address" id="address" value=" <?php echo $row['address']; ?>" required="required"></td>
				</tr><tr>
					<td>備    註：</td>
					<td style="width:250px;height:50px;"><input type="text" name="special" id="special" value=" <?php echo $row['special']; ?>" required="required"></td>
				</tr><tr>
			        <td colspan='2' align="center">
                    <input type="hidden" name="action" value="update">
                        <input class="input" style="width:150px;height:50px;" type="submit" value="確定修改">
                    </td>
                </tr>
        </table></form></center>
    </div>
</body>
<footer id="footer" class="footer"><br>
    <p style="text-align: center;"><font color="white" size=2px face="微軟正黑體"><strong>CAT LOVERS</strong></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://cfa.org/">CFA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://tica.org/zh-tw/">TICA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://www.worldcatcongress.org/">WCC協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">全國動物收容</a></font></p> 
    <br>
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體">Copyright ©2022 CAT LOVERS</font></p> 
</footer>
</html>
