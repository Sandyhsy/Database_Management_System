<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,種類,純種,毛孩">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>貓咪品種</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
.na{
  padding-top: 0.3125rem;
  padding-bottom: 0.3125rem;
  margin-right: 1rem;
  font-size: 1.25rem;
  white-space: nowrap;
  font-weight: 800;
}
.demo{
    line-height:2;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="na" color="black">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php"><font color="black">About Us<br>關於我們</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php"><font color="black">Home<br>首頁</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php"><font color="black">Pet Hospital<br>寵物醫院</a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php"><font color="black">Usual Disease<br>常見疾病</font></a></font></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </from>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <div style="background-image: url('assets/img/header.png');height:100px;opacity:0.6;"></div>
        <div style="height:100px;"></div>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
            <center><table>
                <tr>
                <?php
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM ccats WHERE num='$id'";
                    $result = mysqli_query($link, $sql);
                    $row = mysqli_fetch_assoc($result);
                    echo "<tr>";
                    echo "<td rowspan='5'><img src='".$row['pic']."' width=90%></td>";
                    echo "<td colspan='3'><font face='微軟正黑體'><b>品種：</b>&nbsp;&nbsp;".$row['e_name']."&nbsp;&nbsp;&nbsp;".$row['c_name']."</font></td>";
                    echo "</tr><tr><td height='50px'></td></tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛皮種類：</b></font><font face='微軟正黑體' size='3px'>".$row['fur']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>體型：</b></font><font face='微軟正黑體' size='3px'>".$row['size']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>平均壽命：</b></font><font face='微軟正黑體' size='3px'>".$row['age']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>個性：</b></font><font face='微軟正黑體' size='3px'>".$row['personality']."</font></td>";
                    echo "</tr><tr>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>天生疾病：</b></font><font face='微軟正黑體' size='3px'>".$row['disease']."</font></td>";
                    echo "<td width='30px'></td>";
                    echo "<td width='300px'><font face='微軟正黑體'><b>毛色：</b></font><font face='微軟正黑體' size='3px'>".$row['color']."</font></td>";
                    echo "</tr>";
                ?>
            </table>
            <br><hr style="width:100%;"><br>
            <table class="demo">
                <tr>
                    <td><font face='微軟正黑體'><b>性格：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    唐斯芬克斯貓精力充沛、非常友善、非常聰明而且非常聰滿愛意，對於飼主非常忠心，而且很認主人。
                    唐斯芬克斯貓天性善良、溫順，也很容易整理。牠們的性格相當平衡，對周圍環境非常好奇、精力充沛
                    ，喜歡與人親近和玩遊戲。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                    <td width='1000px'><font face='微軟正黑體'><b>需如何照顧：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    唐斯芬克斯貓是無毛貓，應該每天擦拭以去除皮膚產生的油脂。 他們應該每週洗澡一次或每月兩次。
                    小心極端天氣。 他們可以通過皮膚出汗並在陽光下曬黑，因此請務必向您的獸醫諮詢合適的防曬霜。 
                    雖然唐斯芬克斯貓可能會長出一件冬衣，但它通常很好，不適合非常寒冷的冬天。與所有貓一樣，要
                    定期修剪指甲、清潔耳朵和刷牙，並使用獸醫認可的寵物牙膏，並提供一個漂亮的高抓桿來幫助它們
                    自然的抓撓本能。
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>詳細特徵：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
1） 頭：中型修改楔形，額頭平坦，精細勾勒出顴骨和眉毛。這頭部比它長大約 1/3寬的。就在兩眼之間明顯的壓痕。<br>

2） 耳：大，張開，耳邊寬底座，直立並略微傾斜向前，既不低也不在頂部頭。分開，大約寬度耳根。耳朵的外緣繼續頭部的線。耳塞是圓形。<br>

3） 眼睛：中到大尺寸與頭部大小成比例，杏仁形，朝向耳朵的外角傾斜。不是張大。眼睛之間沒有關係顏色和毛色。<br>

4） 身材：中等大小。中到中等長度，密集，肌肉發達，骨骼強壯，胸部和臀部寬，腹股溝線較深，腹部圓潤。<br>

5） 四肢：長度與身體成比例，中度剔骨，結實肌肉組織。後腿稍長比前面。前腿寬闊。<br>

6） 腳趾：腳趾很長很細並以彎曲的拇指區分向內而不是在前面向下爪子看起來很細長手。爪墊很厚。<br>

7） 尾巴：中長，筆直，從身體到尖端逐漸變細。長度在與身體大小成比例。<br>
                    <font></td>
                </tr>
                <tr><td height='20px'></td></tr>
                <tr>
                    <td><font face='微軟正黑體'><b>歷史小故事：</b><font></td>
                </tr><tr>
                    <td width='1000px'><font face='微軟正黑體' size='3px'>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    為一種俄羅斯品種，其歷史始於 1987 年在俄羅斯頓河畔羅斯托夫市發現的基礎貓科動物。國家教育學院教授Elena Kovaleva遇到了帶著袋子踢足球的小男孩——裡面 袋子裡是一隻因恐懼和痛苦而尖叫的小貓。 埃琳娜拿著袋子把小貓帶回家了。 她給這隻小貓取名為Varvara。Varvara長大後失去了她的頭髮，她為此受到了徒勞的治療。幾年後，Varvara 生下了有毛和完全無毛的小貓。 就像它們的媽媽一樣，有毛的小貓開始掉毛。Irina Nemikina，狂熱的貓飼養員和專業的貓飼養員，救出了一隻小貓，並在幾年內培育出一種全新的俄羅斯貓，一種她命名的無毛貓——唐斯芬克斯。
                    <font></td>
                </tr>
            </table>
            </center>
            </div>
            <?php 
    $i1=$id-1;
    $sql = "SELECT * FROM ccats WHERE num='$i1'";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);
    if(!empty($row)){
        $name = $row['c_name'];
    }
?>
<style>
.test{position:relative;}
.test:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name;?>';
}
</style>
<?php 
    $i2=$id+1;
    $sql1 = "SELECT * FROM ccats WHERE num='$i2'";
    $result1 = mysqli_query($link, $sql1);
    $row1 = mysqli_fetch_assoc($result1);
    if(!empty($row1)){
        $name1 = $row1['c_name'];
    }
?>
<style>
.test1{position:relative;}
.test1:hover::before{
position: absolute;
top: -50px;
left: 10px;
color: #fff;
font-size: .8em;
background: #7d93a8;
padding: 5px;
border-radius: 5px;
content: '<?php echo $name1;?>';
}
</style>
            <table>
                <tr>
                    <td width="50px"></td>
                    <?php $i1 = $id-1;
                        if(!empty($row)){
                        echo "<td align='left' class='test'><a href='cat_introduction$i1.php?id=$i1'><img src='assets/img/arrow-left.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="900px"></td>
                    <?php $i2 = $id+1;
                        if(!empty($row1)){
                            echo "<td align='right' class='test1'><a href='cat_introduction$i2.php?id=$i2'><img src='assets/img/arrow-right.png' width='50%'></a></td>"; 
                        }else{
                            echo "<td width='100px'></td>";
                        }
                    ?>
                    <td width="50px"></td>
                </tr>
            </table>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='登入.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>