<?php
session_start();
$name=$_SESSION['name'];
$_SESSION['name']=$name;
?>
<!DOCTYPE html>
<html lang="zh-TW">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>關於我們管理</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />
        <link rel=stylesheet type="text/css" href="css\all.css">
        <style>
.header{
    background-color: #7d93a8; 
    height:120px;
}
.color{
    color:black;
    border-color:#708090;
    width:280px;
    height:60px;
    background-color:#7d93a8;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.divblock{
	width:1200px;
	height:500px;
	margin:20px auto; 
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
a{
    text-decoration:none
}
a:hover{
    text-decoration:none
}
a{
    text-decoration:none;
}
a:hover{
    text-decoration:none;
}
</style>
    </head>
    <header class="header">
        <table>
            <tr>
                <td width='25'></td>
                <td><br><img src="assets/img/catlogo.png" width=80 height=80 /></td>
                <td width='15'></td>
                <td><font face="Gungsuh" color=white><h2>CAT LOVERS</h2></font></td>
                <td width='325'></td>
                <td valign="bottom">
                    <input class="input" type="button" value="關於我們" onclick="location.href='關於我們.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="貓咪品種" onclick="location.href='貓咪品種.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="寵物醫院" onclick="location.href='寵物醫院.php'"></td>
                <td valign="bottom">
                    <input class="input" type="button" value="常見疾病" onclick="location.href='常見疾病.php'"></td>
                <td valign="bottom">
                    <div class="search-criteria-bar">
                        <input style="height: 34px;" itemprop="query-input" style="height:48px" type="text" name="q" id="q" value placeholder="搜尋" required>
                        <button class="input" id="button-search" type="submit">
                            <i class="fa fa-search" aria-hidden="true"></i>搜 尋
                        </button>
                    </div>
                </td>
                <td valign="top">
<?php
    echo $name;
?>
                </td>
                <td valign="top">
                    <img src="assets/img/exit.png" style="width:20px;height:20px;" onclick="location.href='index.php'">
                </td>
                <td width='25'></td>
            </tr>
        </table>
</header>
<body>
    <div class="divblock">
        <center>
        <from action="aboutus.php" method="POST"><table>
            <tr>
                <td><intput type="text" name="p1" value="現代人飼養寵物的比例越來越高，對於新手而言要飼養什麼類型的寵物是首要面對的問題。"></td>
            </tr><tr>
                <td><intput type="text" name="p2" value="在不熟悉寵物習性的狀況，飼養後會產生許多的問題、衝突，像是不了解寵物天生疾病或個性等等，在這些狀況下都可能會對寵物的身心健康造成影響，對飼主也可能會造成生活上的不便。"></td>
            </tr><tr>
                <td><intput type="text" name="p3" value="想藉此系統幫助想飼養貓咪的人以及飼主們。讓瀏覽者先對貓咪本身做了解，再去評估自身環境、生活方式與經濟狀況，選擇較適合的貓咪品種做飼養。"></td>
            </tr><tr>
                <td><input type="submit" value="確認修改">
            </tr>
        </table></form>
        </center>
    </div>
</body>
<button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
<footer id="footer" class="footer"><br>
    <p style="text-align: center;"><font color="white" size=2px face="微軟正黑體"><strong>CAT LOVERS</strong></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://cfa.org/">CFA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://tica.org/zh-tw/">TICA協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://www.worldcatcongress.org/">WCC協會</a></font></p> 
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體"><a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">全國動物收容</a></font></p> 
    <br>
    <p style="text-align: center;"><font color="white" size=1px face="微軟正黑體">Copyright ©2022 CAT LOVERS</font></p> 
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>
