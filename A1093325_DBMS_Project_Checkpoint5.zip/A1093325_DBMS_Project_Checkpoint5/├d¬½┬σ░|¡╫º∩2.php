<?php
    require 'database.php';
    $newid = $_POST['id'];
    $newhname = $_POST['hname'];
    $newtel = $_POST['tel'];
    $newcounty = $_POST['county'];
    $newdistrict = $_POST['district'];
    $newaddress = $_POST['address'];
    $newspecial = $_POST['special'];

    $sql2 = "SELECT * FROM city WHERE county='$newcounty' AND district='$newdistrict'";
    $result2 = mysqli_query($link,$sql2);
    $row2 = mysqli_fetch_assoc($result2);
    $newcityid = $row2['num'];
    $SQL="UPDATE hospital SET city='$newcityid', hname='$newhname',address='$newaddress',tel='$newtel',special='$newspecial'
                WHERE num='$newid'";
if(mysqli_query($link,$SQL))
{
    echo "<script type='text/javascript'>";
    echo "alert('更新成功')";
    echo "</script>";
    echo "<meta http-equiv='Refresh' content='0; url=b_hospital.php'>";
}
else
{
    echo "<script type='text/javascript'>";
    echo "alert('更新失敗')";
    echo "</script>";
}
?>