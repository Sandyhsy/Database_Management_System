<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,醫院,寵物醫院,24小時營業,貓咪友善,看醫生不緊張">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>寵物醫院</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />     
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
</head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.input{
    border:0;
    background-color:#7d93a8;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.input:hover{ 
    color:black;
    background-color:#a5b6bd;
    border:2px #7d93a8 solid;
    font-style:"微軟正黑體";
    width:110px;
    height:40px;
    font-weight:bold;
    font-size:15px;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
</style>
<body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
            <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="navbar-brand">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php">About Us<br>關於我們</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php">Home<br>首頁</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php">Pet Hospital<br>寵物醫院</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php">Usual Disease<br>常見疾病</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </form>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/hospitalcat.jpeg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="site-heading">
                            <h1>Pet Hospitals</h1>
                            <span class="subheading">Too afraid to go to hospital?</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
            
                    <center><table>
                        <tr>
                            <td align="center"><font color="#507597" face="微軟正黑體">毛孩每次看醫生都是一大挑戰嗎?</font></td>
                            <td height="20"></td>
                            <td rowspan="4"><img src="assets/img/friendly.jpg" height=70></td>
                        </tr><tr>
                            <td height="20"></td>
                        </tr><tr>
                            <td align="center"><font color="#507597" face="微軟正黑體">Cat Lovers推薦全台優質寵物醫院</font></td>
                        </tr><tr>
                            <td align="center"><font color="#507597" face="微軟正黑體">24小時急診、獲得貓咪友善醫院獎的醫院</font></td>
                        </tr>
                    </table></center>
                    <br><br>
                    <table style="border-top:3px #507597 solid;border-bottom:3px #507597 solid;" cellpadding="10" border='0'><form name="myForm" action="hossearch.php" method="POST">
                        <tr><td><font color="#507597" face="微軟正黑體"><b>醫院查詢：</b></font>
                        </td><td width="100px">
                        <select id="college-list" name="county" onChange="renew(this.selectedIndex)" style="width:140px;">
                            <option >請選擇縣市</option>
                            <option id="1">臺北市</option>
                            <option id="2">新北市</option>
                            <option id="3">基隆市</option>
                            <option id="4">桃園縣</option>
                            <option id="5">新竹市</option>
                            <option id="6">新竹縣</option>
                            <option id="7">苗栗縣</option>	
                            <option id="8">臺中市</option>
                            <option id="9">彰化縣</option>
                            <option id="10">南投縣</option>
                            <option id="11">雲林縣</option>	
                            <option id="12">嘉義市</option>	
                            <option id="13">嘉義縣</option>	
                            <option id="14">臺南市</option>	
                            <option id="15">高雄市</option>	
                            <option id="16">屏東縣</option>
                            <option id="17">臺東縣</option>
                            <option id="18">花蓮縣</option>
                            <option id="19">宜蘭縣</option>
                        </select></td><td width="150px">
                        <select name="district" style="width:120px">
	                        <option>區域
                        </select></td><td>
                        <input class="input" id="submit_btn" type="submit" value="查詢"></td>
                        </td></tr>
                    </form></table>
                    <br><br>
                </div>
            </div>
            <center><table>
                <tr>
                    <td width='250'><font face='微軟正黑體' size='5px'>醫院名稱</font></td>
                    <td width='20px'></td>
                    <td width='200'><font face='微軟正黑體' size='5px'>電話</font></td>
                    <td width='20px'></td>
                    <td width='400'><font face='微軟正黑體' size='5px'>地址</font></td>
                    <td width='20px'></td>
                    <td width='150'><font face='微軟正黑體' size='5px'>備註</font></td>
                </tr>
            </table></center>
            <center><hr width=95%></center>
            <center><table>
                <?php
                    $SQL="SELECT * FROM hhospital";
                    $result=mysqli_query($link, $SQL);
                    if(mysqli_num_rows($result) > 0){
                        $count=mysqli_num_rows($result);
                        for($i=1;$i<=$count;$i++){
                            if($i%2!=0){
                                $sql = "SELECT * FROM hhospital WHERE num='$i'";
                                $result = mysqli_query($link, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if(!empty($row)){
                                    $id = $row['hname'];
                                    $SQL = "SELECT town, district FROM aarea c, hhospital h WHERE c.id = h.city AND h.num='$i'";
                                    $result1 = mysqli_query($link, $SQL);
                                    $row1 = mysqli_fetch_assoc($result1);
                                    echo "<tr bgcolor='#EAF2F8'>";
                                    echo "<td width='250'><font face='微軟正黑體' size='4px' name='hname' id='hname'>".$row['hname']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='200'><font face='微軟正黑體' size='4px' name='tel' id='tel'>".$row['tel']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='400'><font face='微軟正黑體' size='4px' name='city' id='city'>".$row1['town'].$row1['district'].$row['address']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='150'><font face='微軟正黑體' size='4px' name='special' id='special'>".$row['special']."</font></td>";
                                    echo "<tr><td height='30'></td>";
                                    echo "</tr>";
                                }
                            }
                            if($i%2==0){
                                $sql = "SELECT * FROM hhospital WHERE num='$i'";
                                $result = mysqli_query($link, $sql);
                                $row = mysqli_fetch_assoc($result);
                                if(!empty($row)){
                                    $id = $row['hname'];
                                    $SQL = "SELECT town,district FROM aarea c, hhospital h WHERE c.id = h.city AND h.num='$i'";
                                    $result1 = mysqli_query($link, $SQL);
                                    $row1 = mysqli_fetch_assoc($result1);
                                    echo "<tr>";
                                    echo "<td width='250'><font face='微軟正黑體' size='4px' name='hname' id='hname'>".$row['hname']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='200'><font face='微軟正黑體' size='4px' name='tel' id='tel'>".$row['tel']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='400'><font face='微軟正黑體' size='4px' name='city' id='city'>".$row1['town'].$row1['district'].$row['address']."</font></td>";
                                    echo "<td width='20px'></td>";
                                    echo "<td width='150'><font face='微軟正黑體' size='4px' name='special' id='special'>".$row['special']."</font></td>";
                                    echo "<tr><td height='30'></td>";
                                    echo "</tr>";
                                }    
                            }
                        }
                    }else{
                        echo "讀不到資料庫!";
                    }  
                ?>
            </table></center>
        </div>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='loginpage.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script>
    department=new Array();
    department[0]=["請由左方選取縣市"];
    department[1]=["北投區", "士林區", "內湖區", "中山區", "松山區", "大同區", "萬華區", "中正區", "大安區", "信義區", "南港區","文山區"];
    department[2]=["板橋區", "三重區", "中和區", "永和區", "新莊區","新店區","土城區","蘆洲區","樹林區","汐止區","鶯歌區","三峽區","淡水區","瑞芳區","五股區","泰山區","林口區","深坑區","石碇區","三芝區","石門區","八里區","平溪區","雙溪區","貢寮區","金山區","萬里區","烏來區","坪林區"];
    department[3]=["仁愛區", "中正區", "信義區", "中山區","安樂區","七堵區","暖暖區"];
    department[4]=["桃園區", "中壢區", "八德區", "平鎮區", "大溪區", "楊梅區", "龜山區", "蘆竹區", "大園區", "觀音區", "新屋區", "龍潭區", "復興區"];
    department[5]=["北區", "東區", "香山區"];
    department[6]=["新豐鄉", "湖口鄉", "竹北市", "新埔鎮", "關西鎮", "芎林鄉", "竹東鎮", "橫山鄉", "賽山鄉", "峨眉鄉", "北埔鄉", "五峰鄉", "尖石鄉"];
    department[7]=["竹南鎮", "頭份市", "三灣鄉", "後龍鎮", "造橋鄉", "頭屋鄉", "獅潭鄉", "南庄鄉", "西湖鄉", "苗栗市", "公館鄉", "通霄鎮", "銅鑼鄉", "大湖鄉", "苑裡鎮", "三義鄉", "卓蘭鎮", "泰安鄉"];
    department[8]=["東區", "西區", "中區", "南區", "北區", "西屯區", "北屯區", "豐原區", "大里區", "太平區", "清水區", "沙鹿區", "大甲區", "東勢區", "梧棲區", "烏日區", "神岡區", "大肚區", "大雅區", "后里區", "霧峰區", "潭子區", "龍井區", "外埔區", "和平區", "石岡區", "大安區", "新社區"];
    department[9]=["伸港鄉", "線西鄉", "和美鎮", "鹿港鎮", "秀水鄉", "彰化市", "花壇鄉", "芬園鄉", "福興鄉", "埔鹽鄉", "大村鄉", "芳苑鄉", "二林鎮", "溪湖鎮", "埔心鄉", "員林市", "永靖鄉", "田尾鄉", "社頭鄉", "埤頭鄉", "北斗鎮", "田中鎮", "大城鄉", "竹塘鄉", "溪州鄉", "二水鄉"];
    department[10]=["南投市", "仁愛鄉", "信義鄉", "埔里鎮", "魚池鄉", "國姓鄉", "水里鄉", "草屯鎮", "中寮鄉", "集集鎮", "鹿谷鄉", "名間鄉", "竹山鎮"];
    department[11]=["林內鄉","斗六市","古坑鄉","莿桐鄉", "斗南鎮", "虎尾鎮", "西螺鎮", "土庫鎮", "北港鎮", "大埤鄉", "二崙鄉", "崙背鄉", "麥寮鄉", "東勢鄉", "褒忠鄉", "臺西鄉", "元長鄉", "四湖鄉", "口湖鄉", "水林鄉"];
    department[12]=["東區", "西區"];
    department[13]=["太保市", "朴子市", "布袋鎮", "大林鎮", "民雄鄉", "溪口鄉", "新港鄉", "六腳鄉", "東石鄉", "義竹鄉", "鹿草鄉", "水上鄉", "中埔鄉", "竹崎鄉", "梅山鄉", "番路鄉", "大埔鄉", "阿里山鄉"];
    department[14]=["新營區", "鹽水區", "白河區", "柳營區", "後壁區", "東山區", "麻豆區", "下營區", "六甲區", "官田區", "大內區", "佳里區", "學甲區", "西港區", "七股區", "將軍區", "北門區", "新化區", "新市區", "善化區", "安定區", "山上區", "玉井區", "楠西區", "南化區", "左鎮區", "仁德區", "歸仁區", "關廟區", "龍崎區", "永康區", "東區", "南區", "中西區", "北區", "安南區", "安平區"];
    department[15]=["楠梓區", "左營區", "鼓山區", "三民區", "苓雅區", "新興區", "前金區", "鹽埕區", "前鎮區", "旗津區", "小港區", "鳳山區", "茂林區", "甲仙區", "六龜區", "杉林區", "美濃區", "內門區", "仁武區", "田寮區", "旗山區", "梓官區", "阿蓮區", "湖內區", "岡山區", "茄萣區", "路竹區", "鳥松區", "永安區", "燕巢區", "大樹區", "大寮區", "林園區", "彌陀區", "橋頭區", "大社區", "那瑪夏區", "桃源區"];
    department[16]=["屏東市", "潮州鎮", "東港鎮", "恆春鎮", "萬丹鄉", "長治鄉", "麟洛鄉", "九如鄉", "里港鄉", "鹽埔鄉", "高樹鄉", "萬巒鄉", "內埔鄉", "竹田鄉", "新埤鄉", "枋寮鄉", "新園鄉", "崁頂鄉", "林邊鄉", "南州鄉", "佳冬鄉", "琉球鄉", "車城鄉", "滿州鄉", "三地門鄉", "霧臺鄉", "瑪家鄉", "泰武鄉", "來義鄉", "春日鄉", "獅子鄉", "枋山鄉", "牡丹鄉"];
    department[17]=["臺東市", "成功鎮", "關山鎮", "卑南鄉", "大武鄉", "太麻里鄉", "東河鄉", "長濱鄉", "鹿野鄉", "池上鄉", "綠島鄉", "延平鄉", "海端鄉", "達仁鄉", "金峰鄉", "蘭嶼鄉"];
    department[18]=["花蓮市", "玉里鎮", "鳳林鎮", "新城鄉", "吉安鄉", "壽豐鄉", "光復鄉", "豐濱鄉", "瑞穗鄉", "富里鄉", "秀林鄉", "萬榮鄉", "卓溪鄉"];
    department[19]=["宜蘭市", "羅東鎮", "蘇澳鎮", "頭城鎮", "礁溪鄉", "壯圍鄉", "員山鄉", "冬山鄉", "五結鄉", "三星鄉", "大同鄉", "南澳鄉"];
                        
    function renew(index){
        for(var i=0;i<department[index].length;i++)
            document.myForm.district.options[i]=new Option(department[index][i], department[index][i]); // 設定新選項
                document.myForm.district.length=department[index].length;
    }
</script>
<script src="/path/twzipcode.js"></script><!-- 台灣行政區 -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>
