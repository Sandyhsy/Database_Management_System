<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPmailer/src/Exception.php';
require 'PHPmailer/src/PHPMailer.php';
require 'PHPmailer/src/SMTP.php';

$name=$_POST["name"];
$email=$_POST["email"];
$message=nl2br($message);

$mail = new PHPMailer(true);
try {
    require 'database.php';
    $SQL="SELECT * FROM user WHERE name='$name'";
    $result = mysqli_query($link,$SQL);
    $row = mysqli_fetch_assoc($result);

    $mail->SMTPDebug = 0;                                 //Enable verbose debug output
    $mail->isSMTP();                                      //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                 //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                             //Enable SMTP authentication
    $mail->Username   = 'hungfish0118@gmail.com';         //SMTP username
    $mail->Password   = 'qmhrhjpxkdflstya';               //SMTP password
    $mail->Port       = 465;  
    $mail->SMTPSecure = 'ssl';                            //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->Charset='UTF-8';
    $mail->setFrom('hungfish0118@gmail.com', 'Cat Lovers');
    $mail->addAddress($email, $name);
    $mail->isHTML(true);
    $mail->Subject = "=?utf-8?B?".base64_encode("Cat Lovers管理員忘記密碼")."?=";
    $mail->Body = $name." 您好, 您的密碼如下:<br>".$row['pwd']."<br><br>";
    $mail->send();
    echo"<meta http-equiv='Refresh' content='0; url=登入.php'>";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>