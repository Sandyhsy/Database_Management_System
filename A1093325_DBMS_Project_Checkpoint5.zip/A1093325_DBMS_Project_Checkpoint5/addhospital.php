<?php 
    session_start();
    $name=$_SESSION['name'];
    $_SESSION['name']=$name;
    require 'database.php';

    $newname = $_POST['name'];
    $newtel = $_POST['tel'];
    $newcounty = $_POST['town'];
    $newdistrict = $_POST['district'];
    $newaddress = $_POST['address'];
    $newspecial = $_POST['special'];
    
    $sqlsame = "SELECT * FROM aarea a, hhospital h WHERE a.town='$newcounty' AND a.district='$newdistrict' AND h.address='$newaddress'";
    $resultsame=mysqli_query($link,$sqlsame);
    $rowsame = mysqli_fetch_assoc($resultsame);
    if(!empty($rowsame)){
        echo "<script>alert('此寵物醫院已存在');</script>";
        echo"<meta http-equiv='Refresh' content='0; url=hos_update.php'>";
    }else{    
        $sqlnum="SELECT num FROM hhospital ORDER BY num DESC LIMIT 1 ";
        $resultnum=mysqli_query($link,$sqlnum);
        $rownum = mysqli_fetch_assoc($resultnum);
        $idnum=$rownum['num'];
        $new=$idnum+1;

        $SQL = "SELECT * FROM aarea WHERE town='$newtown' AND district='$newdistrict'";
        $result1 = mysqli_query($link,$SQL);
        $row1 = mysqli_fetch_assoc($result1);
        $newcity = $row1['id'];

        $sql = "INSERT INTO hhospital (num,hname,tel,city,address,special) VALUES('$new','$newname','$newtel','$newcounty','$newaddress','$newspecial')";
        $result = mysqli_query($link,$sql);
        if (mysqli_affected_rows($link)>0) {
            echo "<script>alert('成功上傳!');</script>";
            echo"<meta http-equiv='Refresh' content='0; url=b_hospital.php'>";
        }
        elseif(mysqli_affected_rows($link)==0) {
            echo "無資料新增";
        }
        else {
        echo "{$sql} 語法執行失敗，錯誤訊息: " . mysqli_error($link);
        }
    }
    mysqli_close($link); 
?>