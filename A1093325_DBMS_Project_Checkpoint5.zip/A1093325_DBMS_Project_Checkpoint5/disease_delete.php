<?php
require 'database.php';
$id = $_GET['id'];
echo $id;

$SQL= "DELETE FROM ddisease WHERE dname='$id'";
if(mysqli_query($link,$SQL))
{
    echo "<script type='text/javascript'>";
    echo "alert('刪除成功')";
    echo "</script>";
    echo "<meta http-equiv='Refresh' content='0; url=b_disease.php'>";
}
else
{
    echo "<script type='text/javascript'>";
    echo "alert('刪除失敗')";
    echo "</script>";
}
?>