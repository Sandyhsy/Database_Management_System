<?php
    require "database.php";
?>
<!DOCTYPE html>
<html lang="zh-TW">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="keyword" content="貓咪,品種,寵物,毛小孩,寵物醫院,貓咪相關疾病,常見疾病">
        <meta name="description" content="cats" />
        <meta name="author" content="Sandy Huang" />
        <title>關於我們</title>
        <link rel="icon" type="image/x-icon" href="assets/img/catlogo.png" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/all.css" rel="stylesheet" />

    </head>
<style>
.search{
    width:200px;
    height:40px;
    opacity: 0.75;
}
.toTop-arrow {
  width: 2.5rem;
  height: 2.5rem;
  padding: 0;
  margin: 40px;
  border: 0;
  border-radius: 100%;
  opacity: 0.6;
  background: #507597;
  cursor: pointer;
  position:fixed;
  right: 1rem;
  bottom: 1rem;
  display: none;
  }
.toTop-arrow::before {
  transform: rotate(-45deg) translate(0, -50%);
  left: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background: #a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow::after {
  transform: rotate(45deg) translate(0, -50%);
  right: 0.5rem;
  width: 18px;
  height: 5px;
  border-radius: 3px;
  background:	#a5b6bd;
  position: absolute;
  content: "";
}
.toTop-arrow:focus {
  outline: none;
}
</style>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a href="index.php"><img src="assets/img/catlogo.png" width=60 height=60><font class="navbar-brand">&nbsp&nbspCat Lovers</font></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <from action="search.php" method="get"><div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.php">About Us<br>關於我們</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php">Home<br>首頁</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="hospital.php">Pet Hospital<br>寵物醫院</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="disease.php">Usual Disease<br>常見疾病</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href=" ">  <br>  </a></li>
                        <form action="catsearch.php" method="POST">
                            <li class="nav-item"><span class="icon"><i class="fa fa-search"></i></span>
                                <input type="search" class="search" name="search" placeholder="貓咪品種查詢"></li>
                        </form>
                    </ul>
                </div></from>
                </div>
            </div>  
        </nav>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/aboutus.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="page-heading">
                            <h1>About Us</h1>
                            <span class="subheading">What we are doing is...</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <font face='微軟正黑體'>
                        <p style="line-height:2;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp現代人飼養寵物的比例越來越高，但對於寵物的習性、天生疾病等知識都是到真正飼養後才開始慢慢了解，有的時候甚至會有飼主因此棄養寵物。</p>
                        <p style="line-height:2;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp此外還有許多想飼養寵物的新手，首要面對的問題可能是要飼養哪種類型的寵物。基於以上的問題，所以想藉此系統幫助想飼養貓咪的人以及飼主們。能先對貓咪本身做了解，再去評估自身環境、生活方式與經濟狀況，選擇較適合的貓咪品種做飼養。</p>
                        <p style="line-height:2;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp在不熟悉寵物習性的狀況，飼養後會產生許多的問題、衝突，像是不了解寵物天生疾病或個性等等，在這些狀況下都可能會對寵物的身心健康造成影響，對飼主也可能會造成生活上的不便。</p>
                        <p style="line-height:2;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp想藉此網站幫助想飼養貓咪的人以及飼主們。讓瀏覽者先對貓咪本身做了解，再去評估自身環境、生活方式與經濟狀況，選擇較適合的貓咪品種做飼養。</p>
                        </font>
                    </div>
                </div>
            </div>
        </main>
        <button type="button" id="BackTop" class="toTop-arrow"></button><!--到最上-->
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                        <li class="list-inline-item">
                            <a href="https://cfa.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/CFA.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="https://tica.org/zh-tw/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/TICA.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://www.worldcatcongress.org/">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/WCC.png" height="60"></i>
                                </span>
                            </a>
                        </li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item"></li>
                        <li class="list-inline-item">
                            <a href="https://asms.coa.gov.tw/Amlapp/App/Default.aspx">
                                <span class="fa-stack fa-lg">
                                    <i><img src="assets/img/logo.png" width="60"></i>
                                </span>
                            </a>
                        </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Cat Lovers 2022 </div>
                    </div>
                </div>
            </div>
            <div style="text-align:right;"><img src="assets/img/user.png" style="width:20px;height:20px;" onclick="location.href='loginpage.php'"></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
//到最上面的按鈕
$(function(){
	$('#BackTop').click(function(){ 
		$('html,body').animate({scrollTop:0}, 333);
	});
	$(window).scroll(function() {
		if ( $(this).scrollTop() > 300 ){
			$('#BackTop').fadeIn(222);
		} else {
			$('#BackTop').stop().fadeOut(222);
		}
	}).scroll();
});//到最上面的按鈕
</script>
</html>
