<?php 
session_start();
$name=$_SESSION['name'];
$_SESSION['name']=$name;
require 'database.php';

    $newdname = $_POST['dname'];
    $newdcause = $_POST['dcause'];
    $newdprevent = $_POST['dprevent']; 

    $sqlsame = "SELECT * FROM ddisease WHERE dname='$dname'";
    $resultsame=mysqli_query($link,$sqlsame);
    $rowsame = mysqli_fetch_assoc($resultsame);
    if(!empty($rowsame)){
        echo "<script>alert('此常見疾病已存在');</script>";
        echo"<meta http-equiv='Refresh' content='0; url=disease_update.php'>";
    }else{ 
        $sqlnum="SELECT num FROM ddisease ORDER BY num DESC LIMIT 1 ";
        $resultnum=mysqli_query($link,$sqlnum);
        $rownum = mysqli_fetch_assoc($resultnum);
        $idnum=$rownum['num'];
        $new=$idnum+1;
    
        $sql = "INSERT INTO ddisease (num,dname,dcause,dprevent) VALUES('$new','$newdname','$newdcause','$newdprevent')";
        $result = mysqli_query($link,$sql);
        if (mysqli_affected_rows($link)>0) {
            echo "<script>alert('成功上傳!');</script>";
            echo"<meta http-equiv='Refresh' content='0; url=b_disease.php'>";
        }
        else if(mysqli_affected_rows($link)==0) {
            echo "無資料新增";
        }
        else {
            echo "{$sql} 語法執行失敗，錯誤訊息: " . mysqli_error($link);
        }
    }
 mysqli_close($link); 
?>